# Advertising

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nugg** | **Boolean** |  |  [optional]
**played** | **Boolean** |  |  [optional]
**tag** | **String** |  |  [optional]
**time** | **Integer** |  |  [optional]
