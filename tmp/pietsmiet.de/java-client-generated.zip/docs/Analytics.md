# Analytics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**google** | **String** |  |  [optional]
