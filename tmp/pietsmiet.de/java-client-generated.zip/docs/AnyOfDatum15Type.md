# AnyOfDatum15Type

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
