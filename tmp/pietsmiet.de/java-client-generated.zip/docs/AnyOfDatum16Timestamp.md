# AnyOfDatum16Timestamp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
