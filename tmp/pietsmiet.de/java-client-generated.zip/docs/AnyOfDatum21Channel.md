# AnyOfDatum21Channel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
