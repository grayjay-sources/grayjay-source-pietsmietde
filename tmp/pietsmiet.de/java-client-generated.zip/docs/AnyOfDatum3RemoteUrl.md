# AnyOfDatum3RemoteUrl

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
