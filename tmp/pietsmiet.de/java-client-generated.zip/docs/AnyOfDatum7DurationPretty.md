# AnyOfDatum7DurationPretty

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
