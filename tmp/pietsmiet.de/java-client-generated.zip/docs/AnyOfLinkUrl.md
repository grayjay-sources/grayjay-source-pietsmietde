# AnyOfLinkUrl

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
