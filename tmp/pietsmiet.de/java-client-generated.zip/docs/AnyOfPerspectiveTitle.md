# AnyOfPerspectiveTitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
