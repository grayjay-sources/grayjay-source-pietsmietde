# AnyOfUser4Avatar

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
