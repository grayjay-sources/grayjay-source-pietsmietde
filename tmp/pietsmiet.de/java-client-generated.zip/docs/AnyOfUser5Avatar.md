# AnyOfUser5Avatar

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
