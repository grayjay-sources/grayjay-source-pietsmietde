# AnyOfVariation1Url

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
