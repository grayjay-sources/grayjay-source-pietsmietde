# AtedAt

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**timezone** | **String** |  |  [optional]
**timezoneType** | **Integer** |  |  [optional]
