# AuthorPreferences

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**publicProfile** | **Boolean** |  |  [optional]
**subscriptionEnableIdentification** | **Boolean** |  |  [optional]
