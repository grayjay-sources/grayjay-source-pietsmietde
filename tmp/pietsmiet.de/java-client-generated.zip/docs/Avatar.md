# Avatar

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collection** | [**CollectionEnum**](#CollectionEnum) |  |  [optional]
**id** | **Integer** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**variations** | [**List&lt;AvatarVariation&gt;**](AvatarVariation.md) |  |  [optional]

<a name="CollectionEnum"></a>
## Enum: CollectionEnum
Name | Value
---- | -----
AVATAR | &quot;avatar&quot;
