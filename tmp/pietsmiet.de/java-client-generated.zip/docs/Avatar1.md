# Avatar1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collection** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**variations** | [**List&lt;Variation&gt;**](Variation.md) |  |  [optional]
