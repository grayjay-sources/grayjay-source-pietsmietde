# Braintree

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addOns** | **List&lt;Object&gt;** |  |  [optional]
**billingDayOfMonth** | **Integer** |  |  [optional]
**billingPeriodEndDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**billingPeriodStartDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**currentBillingCycle** | **Integer** |  |  [optional]
**daysPastDue** | **Object** |  |  [optional]
**discounts** | [**List&lt;Discount&gt;**](Discount.md) |  |  [optional]
**failureCount** | **Integer** |  |  [optional]
**firstBillingDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**neverExpires** | **Boolean** |  |  [optional]
**nextBillAmount** | **String** |  |  [optional]
**nextBillingDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**nextBillingPeriodAmount** | **String** |  |  [optional]
**numberOfBillingCycles** | **Object** |  |  [optional]
**price** | **String** |  |  [optional]
**status** | **String** |  |  [optional]
