# BraintreePlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addOns** | **List&lt;Object&gt;** |  |  [optional]
**billingDayOfMonth** | **Object** |  |  [optional]
**billingFrequency** | **Integer** |  |  [optional]
**createdAt** | [**AtedAt**](AtedAt.md) |  |  [optional]
**currencyIsoCode** | **String** |  |  [optional]
**description** | **Object** |  |  [optional]
**discounts** | **List&lt;Object&gt;** |  |  [optional]
**id** | **String** |  |  [optional]
**merchantId** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**numberOfBillingCycles** | **Object** |  |  [optional]
**plans** | **List&lt;Object&gt;** |  |  [optional]
**price** | **String** |  |  [optional]
**trialDuration** | **Object** |  |  [optional]
**trialDurationUnit** | **Object** |  |  [optional]
**trialPeriod** | **Boolean** |  |  [optional]
**updatedAt** | [**AtedAt**](AtedAt.md) |  |  [optional]
