# Brand

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**color** | [**ColorEnum**](#ColorEnum) |  |  [optional]
**link** | **String** |  |  [optional]
**logo** | **String** |  |  [optional]

<a name="ColorEnum"></a>
## Enum: ColorEnum
Name | Value
---- | -----
_039A45 | &quot;039a45&quot;
