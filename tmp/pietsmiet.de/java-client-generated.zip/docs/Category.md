# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**slug** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
