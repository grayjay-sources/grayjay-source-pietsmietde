# ChannelVideoCountGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channel** | [**Channel**](Channel.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
