# Channels

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**viaMail** | **Boolean** |  |  [optional]
**viaWebsite** | **Boolean** |  |  [optional]
