# Chromecast

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**receiverApplicationId** | **String** |  |  [optional]
