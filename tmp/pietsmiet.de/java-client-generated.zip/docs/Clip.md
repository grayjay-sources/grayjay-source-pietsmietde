# Clip

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | **String** |  |  [optional]
**finished** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**slug** | **String** |  |  [optional]
**timeEnd** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**timeStart** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**title** | **Object** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**video** | [**Video**](Video.md) |  |  [optional]
