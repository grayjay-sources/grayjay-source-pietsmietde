# Comment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**approved** | **Boolean** |  |  [optional]
**countReplies** | **Integer** |  |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**dislikesCount** | **Integer** |  |  [optional]
**id** | **Integer** |  |  [optional]
**isReply** | **Boolean** |  |  [optional]
**likesCount** | **Integer** |  |  [optional]
**pinned** | **Object** |  |  [optional]
**reply** | **Integer** |  |  [optional]
**subject** | [**Subject1**](Subject1.md) |  |  [optional]
**text** | **String** |  |  [optional]
**timestamp** | **Integer** |  |  [optional]
**user** | [**User2**](User2.md) |  |  [optional]
