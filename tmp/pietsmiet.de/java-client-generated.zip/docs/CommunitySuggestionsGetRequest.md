# CommunitySuggestionsGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;Datum13&gt;**](Datum13.md) |  |  [optional]
**links** | [**Links**](Links.md) |  |  [optional]
**meta** | [**Meta**](Meta.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
