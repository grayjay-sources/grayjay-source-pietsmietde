# ConfigAssetVersionGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hash** | **String** |  |  [optional]
**success** | **Boolean** |  |  [optional]
