# ConfigEnumerationsCountriesGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;Datum1&gt;**](Datum1.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
