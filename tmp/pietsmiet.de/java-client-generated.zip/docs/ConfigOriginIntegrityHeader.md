# ConfigOriginIntegrityHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**h** | [**HEnum**](#HEnum) | Base64 Encoded X-Origin-Integrity Header Name |  [optional]
**v** | **String** | Base64 Encoded X-Origin-Integrity Header Value |  [optional]

<a name="HEnum"></a>
## Enum: HEnum
Name | Value
---- | -----
X_ORIGIN_INTEGRITY | &quot;X-Origin-Integrity&quot;
WC1PCMLNAW4TSW50ZWDYAXR5 | &quot;WC1PcmlnaW4tSW50ZWdyaXR5&quot;
