# Counts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **Integer** |  |  [optional]
**channels** | **Integer** |  |  [optional]
**playlists** | **Integer** |  |  [optional]
**podcasts** | **Integer** |  |  [optional]
**suggestions** | **Integer** |  |  [optional]
**tags** | **Integer** |  |  [optional]
**videos** | **Integer** |  |  [optional]
