# Data

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_notifications** | **Integer** |  |  [optional]
**actions** | [**List&lt;Action&gt;**](Action.md) |  |  [optional]
**icon** | **String** |  |  [optional]
**text** | **String** |  |  [optional]
