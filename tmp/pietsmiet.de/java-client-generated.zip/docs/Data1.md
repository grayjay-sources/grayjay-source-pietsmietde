# Data1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**latestArticles** | [**List&lt;LatestArticle&gt;**](LatestArticle.md) |  |  [optional]
**latestPlaylists** | [**List&lt;LatestPlaylist&gt;**](LatestPlaylist.md) |  |  [optional]
**latestPodcasts** | [**List&lt;LatestPodcast&gt;**](LatestPodcast.md) |  |  [optional]
**latestVideos** | [**List&lt;LatestVideo&gt;**](LatestVideo.md) |  |  [optional]
**schedules** | [**List&lt;Schedule&gt;**](Schedule.md) |  |  [optional]
**topUsers** | [**List&lt;TopUser&gt;**](TopUser.md) |  |  [optional]
**trendingVideos** | [**List&lt;TrendingVideo&gt;**](TrendingVideo.md) |  |  [optional]
**upcomingSchedules** | **List&lt;Object&gt;** |  |  [optional]
