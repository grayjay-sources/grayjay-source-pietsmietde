# Data3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qr** | **String** |  |  [optional]
**secret** | **String** |  |  [optional]
