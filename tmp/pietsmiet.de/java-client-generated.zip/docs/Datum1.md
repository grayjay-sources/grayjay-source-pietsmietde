# Datum1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  |  [optional]
**flatUrl** | **String** |  |  [optional]
**localizedName** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**tax** | **Integer** |  |  [optional]
