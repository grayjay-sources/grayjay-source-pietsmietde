# Datum10

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | [**Author**](Author.md) |  |  [optional]
**categories** | [**List&lt;Category&gt;**](Category.md) |  |  [optional]
**commentsCount** | **Integer** |  |  [optional]
**featured** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**intro** | **String** |  |  [optional]
**preferences** | [**DatumPreferences**](DatumPreferences.md) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**slug** | **String** |  |  [optional]
**text** | **Object** |  |  [optional]
**thumbnail** | [**Thumbnail**](Thumbnail.md) |  |  [optional]
**title** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
