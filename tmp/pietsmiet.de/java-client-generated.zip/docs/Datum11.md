# Datum11

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**data** | [**Data**](Data.md) |  |  [optional]
**id** | [**UUID**](UUID.md) |  |  [optional]
**notifiableId** | **Integer** |  |  [optional]
**notifiableType** | [**NotifiableTypeEnum**](#NotifiableTypeEnum) |  |  [optional]
**read** | **Boolean** |  |  [optional]
**readAt** | **AnyOfDatum11ReadAt** |  |  [optional]
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]

<a name="NotifiableTypeEnum"></a>
## Enum: NotifiableTypeEnum
Name | Value
---- | -----
USER | &quot;user&quot;

<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
USERTWOFACTORDISABLED | &quot;App\\Notifications\\UserTwoFactorDisabled&quot;
USERTWOFACTORENABLED | &quot;App\\Notifications\\UserTwoFactorEnabled&quot;
USERPASSWORDCHANGED | &quot;App\\Notifications\\UserPasswordChanged&quot;
