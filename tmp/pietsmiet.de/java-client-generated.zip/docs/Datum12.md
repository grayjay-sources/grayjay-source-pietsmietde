# Datum12

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**braintreeId** | **String** |  |  [optional]
**braintreePlan** | [**BraintreePlan**](BraintreePlan.md) |  |  [optional]
**details** | [**Details**](Details.md) |  |  [optional]
**enabled** | **Boolean** |  |  [optional]
**id** | **String** |  |  [optional]
**options** | [**Options1**](Options1.md) |  |  [optional]
**supportAddOn** | **AnyOfDatum12SupportAddOn** |  |  [optional]
**type** | **String** |  |  [optional]
