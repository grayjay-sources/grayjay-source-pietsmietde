# Datum13

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commentsCount** | **Integer** |  |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**description** | **String** |  |  [optional]
**descriptionRaw** | **String** |  |  [optional]
**dislikesCount** | **Integer** |  |  [optional]
**id** | **Integer** |  |  [optional]
**likesCount** | **Integer** |  |  [optional]
**participantCount** | **AnyOfDatum13ParticipantCount** |  |  [optional]
**participantLineup** | **AnyOfDatum13ParticipantLineup** |  |  [optional]
**participantLineupDescription** | **String** |  |  [optional]
**referringTo** | **AnyOfDatum13ReferringTo** |  |  [optional]
**slug** | **String** |  |  [optional]
**status** | [**Status**](Status.md) |  |  [optional]
**title** | **String** |  |  [optional]
**type** | **Integer** |  |  [optional]
**typeDescription** | **String** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**url** | **AnyOfDatum13Url** |  |  [optional]
**urlDomain** | **AnyOfDatum13UrlDomain** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
**user** | [**User**](User.md) |  |  [optional]
**voteable** | **Boolean** |  |  [optional]
