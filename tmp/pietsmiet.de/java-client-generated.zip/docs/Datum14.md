# Datum14

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**externalUrl** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**live** | **Integer** |  |  [optional]
**service** | **Integer** |  |  [optional]
**streamGame** | **Object** |  |  [optional]
**streamId** | **String** |  |  [optional]
**streamStartedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**streamThumbnail** | **String** |  |  [optional]
**streamTitle** | **String** |  |  [optional]
**streamViewerCount** | **Integer** |  |  [optional]
**type** | **Integer** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**userAvatar** | **String** |  |  [optional]
**userBanner** | **String** |  |  [optional]
**userDescription** | **String** |  |  [optional]
**userDisplayName** | **String** |  |  [optional]
**userId** | **Integer** |  |  [optional]
**userName** | **String** |  |  [optional]
**userType** | **String** |  |  [optional]
