# Datum15

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ad** | **Boolean** |  |  [optional]
**id** | **AnyOfDatum15Id** |  |  [optional]
**publishDate** | **AnyOfDatum15PublishDate** |  |  [optional]
**title** | **String** |  |  [optional]
**type** | **AnyOfDatum15Type** |  |  [optional]
**url** | **String** |  |  [optional]
