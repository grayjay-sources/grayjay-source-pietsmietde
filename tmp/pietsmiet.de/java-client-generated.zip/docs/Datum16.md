# Datum16

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**approved** | **Boolean** |  |  [optional]
**countReplies** | **Integer** |  |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**dislikesCount** | **Integer** |  |  [optional]
**id** | **Integer** |  |  [optional]
**isReply** | **Boolean** |  |  [optional]
**likesCount** | **Integer** |  |  [optional]
**pinned** | **Boolean** |  |  [optional]
**reply** | **AnyOfDatum16Reply** |  |  [optional]
**text** | **String** |  |  [optional]
**timestamp** | **AnyOfDatum16Timestamp** |  |  [optional]
**user** | [**User4**](User4.md) |  |  [optional]
