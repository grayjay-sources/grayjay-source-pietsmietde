# Datum17

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**id** | **Integer** |  |  [optional]
**objectId** | **Integer** |  |  [optional]
**objectType** | [**ObjectTypeEnum**](#ObjectTypeEnum) |  |  [optional]
**timestamp** | **Integer** |  |  [optional]
**timestampPretty** | **String** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**userId** | **Integer** |  |  [optional]

<a name="ObjectTypeEnum"></a>
## Enum: ObjectTypeEnum
Name | Value
---- | -----
VIDEO | &quot;video&quot;
PODCASTEPISODE | &quot;podcastEpisode&quot;
