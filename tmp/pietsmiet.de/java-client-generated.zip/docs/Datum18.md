# Datum18

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**date** | [**LocalDate**](LocalDate.md) |  |  [optional]
**description** | **String** |  |  [optional]
**full** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**intro** | **Object** |  |  [optional]
**items** | [**List&lt;Item&gt;**](Item.md) |  |  [optional]
**thumbnail** | [**Thumbnail**](Thumbnail.md) |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
