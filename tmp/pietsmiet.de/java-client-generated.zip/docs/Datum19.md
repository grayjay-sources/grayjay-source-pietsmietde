# Datum19

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**id** | **String** |  |  [optional]
**pending** | **Boolean** |  |  [optional]
**status** | **String** |  |  [optional]
**statusColor** | **String** |  |  [optional]
**statusDescription** | **String** |  |  [optional]
**total** | **String** |  |  [optional]
