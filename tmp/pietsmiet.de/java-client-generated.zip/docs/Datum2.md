# Datum2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **Object** |  |  [optional]
**firstVideo** | [**FirstVideo**](FirstVideo.md) |  |  [optional]
**followingsCount** | **Integer** |  |  [optional]
**id** | **Integer** |  |  [optional]
**slug** | **String** |  |  [optional]
**thumbnail** | **Object** |  |  [optional]
**title** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
**videosCount** | **Integer** |  |  [optional]
