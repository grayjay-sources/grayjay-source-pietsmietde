# Datum21

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channel** | **AnyOfDatum21Channel** |  |  [optional]
**description** | **Object** |  |  [optional]
**firstVideo** | **AnyOfDatum21FirstVideo** |  |  [optional]
**followingsCount** | **Integer** |  |  [optional]
**id** | **Integer** |  |  [optional]
**metaTags** | **Object** |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**slug** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**type** | **Integer** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
**videosCount** | **Integer** |  |  [optional]
