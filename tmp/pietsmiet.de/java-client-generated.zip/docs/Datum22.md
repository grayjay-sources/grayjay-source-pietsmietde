# Datum22

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | **String** |  |  [optional]
**finished** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**slug** | **String** |  |  [optional]
**thumbnail** | [**DatumThumbnail**](DatumThumbnail.md) |  |  [optional]
**timeEnd** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**timeStart** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**title** | **String** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**user** | [**User**](User.md) |  |  [optional]
**video** | [**Video**](Video.md) |  |  [optional]
**viewsCount** | **Integer** |  |  [optional]
