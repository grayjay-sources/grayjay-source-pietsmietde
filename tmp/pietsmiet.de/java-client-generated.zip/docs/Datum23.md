# Datum23

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**id** | **Integer** |  |  [optional]
**subjectId** | **Integer** |  |  [optional]
**subjectType** | [**SubjectTypeEnum**](#SubjectTypeEnum) |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**userId** | **Integer** |  |  [optional]

<a name="SubjectTypeEnum"></a>
## Enum: SubjectTypeEnum
Name | Value
---- | -----
COMMENT | &quot;comment&quot;
VIDEO | &quot;video&quot;
TAG | &quot;tag&quot;
SUGGESTION | &quot;suggestion&quot;
