# Datum24

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category** | [**OtherCategory**](OtherCategory.md) |  |  [optional]
**commentsCount** | **Integer** |  |  [optional]
**description** | **String** |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**metaTags** | **Object** |  |  [optional]
**mime** | [**MimeEnum**](#MimeEnum) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**size** | **Integer** |  |  [optional]
**slug** | **String** |  |  [optional]
**sourceUrl** | **String** |  |  [optional]
**thumbnail** | [**Thumbnail**](Thumbnail.md) |  |  [optional]
**title** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]

<a name="MimeEnum"></a>
## Enum: MimeEnum
Name | Value
---- | -----
AUDIO_MPEG | &quot;audio/mpeg&quot;
