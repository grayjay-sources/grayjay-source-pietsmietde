# Datum3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cumulative** | **Boolean** |  |  [optional]
**description** | **Object** |  |  [optional]
**episodesCount** | **Integer** |  |  [optional]
**feed** | [**Feed**](Feed.md) |  |  [optional]
**id** | **Integer** |  |  [optional]
**remoteUrl** | **AnyOfDatum3RemoteUrl** |  |  [optional]
**slug** | **String** |  |  [optional]
**spotifyUrl** | **Object** |  |  [optional]
**title** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
