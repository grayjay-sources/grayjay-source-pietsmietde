# Datum4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**extra** | **List&lt;Object&gt;** |  |  [optional]
**icon** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**title** | **String** |  |  [optional]
**type** | **Integer** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**userId** | **Integer** |  |  [optional]
