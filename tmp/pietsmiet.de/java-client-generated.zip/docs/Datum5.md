# Datum5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channels** | [**List&lt;Channel&gt;**](Channel.md) |  |  [optional]
**commentsCount** | **Integer** |  |  [optional]
**description** | **String** |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | **String** |  |  [optional]
**featured** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**likesCount** | **Integer** |  |  [optional]
**perspectives** | [**List&lt;Perspective&gt;**](Perspective.md) |  |  [optional]
**preferences** | [**Preferences**](Preferences.md) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**remote** | **Boolean** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**shortUrl** | **String** |  |  [optional]
**slug** | **String** |  |  [optional]
**thumbnail** | [**Thumbnail**](Thumbnail.md) |  |  [optional]
**title** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
