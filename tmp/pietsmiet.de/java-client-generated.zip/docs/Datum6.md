# Datum6

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **Boolean** |  |  [optional]
**braintree** | [**Braintree**](Braintree.md) |  |  [optional]
**cancelled** | **Boolean** |  |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**endsAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**gifted** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**name** | **Object** |  |  [optional]
**onGracePeriod** | **Boolean** |  |  [optional]
**onTrial** | **Boolean** |  |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]
**sponsored** | **Boolean** |  |  [optional]
**trialEndsAt** | **Object** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**valid** | **Boolean** |  |  [optional]
