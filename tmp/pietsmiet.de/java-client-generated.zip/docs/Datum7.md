# Datum7

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | [**Author**](Author.md) |  |  [optional]
**categories** | [**List&lt;CategoryElement&gt;**](CategoryElement.md) |  |  [optional]
**category** | [**PurpleCategory**](PurpleCategory.md) |  |  [optional]
**channels** | [**List&lt;Channel&gt;**](Channel.md) |  |  [optional]
**commentsCount** | **Object** |  |  [optional]
**description** | **Object** |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | **AnyOfDatum7DurationPretty** |  |  [optional]
**featured** | **Boolean** |  |  [optional]
**followingsCount** | **AnyOfDatum7FollowingsCount** |  |  [optional]
**id** | **Integer** |  |  [optional]
**intro** | **String** |  |  [optional]
**likesCount** | **Object** |  |  [optional]
**metaTags** | **AnyOfDatum7MetaTags** |  |  [optional]
**mime** | [**MimeEnum**](#MimeEnum) |  |  [optional]
**preferences** | [**DatumPreferences**](DatumPreferences.md) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**remote** | **Boolean** |  |  [optional]
**remoteUrl** | **AnyOfDatum7RemoteUrl** |  |  [optional]
**shortUrl** | **String** |  |  [optional]
**size** | **Integer** |  |  [optional]
**slug** | **String** |  |  [optional]
**sourceUrl** | **String** |  |  [optional]
**text** | **Object** |  |  [optional]
**thumbnail** | [**Thumbnail**](Thumbnail.md) |  |  [optional]
**title** | **String** |  |  [optional]
**type** | **Integer** |  |  [optional]
**url** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
**videosCount** | **AnyOfDatum7VideosCount** |  |  [optional]

<a name="MimeEnum"></a>
## Enum: MimeEnum
Name | Value
---- | -----
AUDIO_MPEG | &quot;audio/mpeg&quot;
