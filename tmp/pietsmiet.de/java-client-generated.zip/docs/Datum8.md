# Datum8

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**dislikesCount** | **Integer** |  |  [optional]
**id** | **Integer** |  |  [optional]
**likesCount** | **Integer** |  |  [optional]
**slug** | **String** |  |  [optional]
**taggableId** | **Integer** |  |  [optional]
**taggableType** | [**TaggableTypeEnum**](#TaggableTypeEnum) |  |  [optional]
**title** | **String** |  |  [optional]
**total** | **Integer** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**user** | [**User**](User.md) |  |  [optional]

<a name="TaggableTypeEnum"></a>
## Enum: TaggableTypeEnum
Name | Value
---- | -----
VIDEO | &quot;video&quot;
