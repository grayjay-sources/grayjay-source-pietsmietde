# Datum9

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**avatar** | **AnyOfDatum9Avatar** |  |  [optional]
**banner** | **AnyOfDatum9Banner** |  |  [optional]
**description** | **AnyOfDatum9Description** |  |  [optional]
**followingsCount** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
**publicSocialAccounts** | [**List&lt;PublicSocialAccount&gt;**](PublicSocialAccount.md) |  |  [optional]
**team** | **Boolean** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
**username** | **String** |  |  [optional]
**videosCount** | **Object** |  |  [optional]
