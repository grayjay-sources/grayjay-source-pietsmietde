# DatumPreferences

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clips** | **Boolean** |  |  [optional]
**comments** | **Boolean** |  |  [optional]
**likes** | **Boolean** |  |  [optional]
**shares** | **Boolean** |  |  [optional]
**tags** | **Boolean** |  |  [optional]
