# Details

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**color** | **String** |  |  [optional]
**details** | [**List&lt;Detail&gt;**](Detail.md) |  |  [optional]
**perks** | [**List&lt;Detail&gt;**](Detail.md) |  |  [optional]
**subTitle** | **String** |  |  [optional]
**supportPerks** | [**List&lt;SupportPerk&gt;**](SupportPerk.md) |  |  [optional]
**title** | **String** |  |  [optional]
