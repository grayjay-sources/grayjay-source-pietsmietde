# Discount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **String** |  |  [optional]
**currentBillingCycle** | **Integer** |  |  [optional]
**id** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**neverExpires** | **Boolean** |  |  [optional]
**numberOfBillingCycles** | **Object** |  |  [optional]
**quantity** | **Integer** |  |  [optional]
