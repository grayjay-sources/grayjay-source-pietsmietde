# Episode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category** | [**OtherCategory**](OtherCategory.md) |  |  [optional]
**commentsCount** | **Object** |  |  [optional]
**description** | **String** |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**metaTags** | **Object** |  |  [optional]
**mime** | **String** |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**size** | **Integer** |  |  [optional]
**slug** | **String** |  |  [optional]
**sourceUrl** | **String** |  |  [optional]
**thumbnail** | [**Thumbnail**](Thumbnail.md) |  |  [optional]
**title** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
