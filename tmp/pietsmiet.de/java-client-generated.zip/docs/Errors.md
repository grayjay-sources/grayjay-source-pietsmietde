# Errors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentPassword** | **List&lt;String&gt;** |  |  [optional]
