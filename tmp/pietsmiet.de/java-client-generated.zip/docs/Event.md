# Event

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | **Integer** |  |  [optional]
**properties** | [**Properties**](Properties.md) |  |  [optional]
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]

<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
NAVIGATION | &quot;navigation&quot;
VIEW | &quot;view&quot;
PLAYER_PLAY | &quot;player_play&quot;
PLAYER_FIRST_PLAY | &quot;player_first_play&quot;
PLAYER_PAUSE | &quot;player_pause&quot;
USER_VIEW | &quot;user_view&quot;
