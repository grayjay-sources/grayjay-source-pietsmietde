# Feed

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**note** | **Object** |  |  [optional]
**remoteUrl** | **AnyOfFeedRemoteUrl** |  |  [optional]
**slug** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
