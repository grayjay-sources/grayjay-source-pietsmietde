# FirstVideo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commentsCount** | **Object** |  |  [optional]
**description** | **Object** |  |  [optional]
**featured** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**likesCount** | **Object** |  |  [optional]
**preferences** | [**LatestArticlePreferences**](LatestArticlePreferences.md) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**remote** | **Boolean** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**shortUrl** | **String** |  |  [optional]
**slug** | **String** |  |  [optional]
**thumbnail** | [**FirstVideoThumbnail**](FirstVideoThumbnail.md) |  |  [optional]
**title** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
