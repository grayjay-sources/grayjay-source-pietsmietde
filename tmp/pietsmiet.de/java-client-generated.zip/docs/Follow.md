# Follow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**subject** | [**Subject**](Subject.md) |  |  [optional]
**subjectType** | **String** |  |  [optional]
**userId** | **Integer** |  |  [optional]
