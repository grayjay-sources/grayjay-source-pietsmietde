# From

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **AnyOfFromName** |  |  [optional]
**path** | **String** |  |  [optional]
