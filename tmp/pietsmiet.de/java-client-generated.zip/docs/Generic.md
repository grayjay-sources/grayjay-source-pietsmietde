# Generic

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**analytics** | [**Analytics**](Analytics.md) |  |  [optional]
**autoplay** | **Boolean** |  |  [optional]
**chromecast** | [**Chromecast**](Chromecast.md) |  |  [optional]
**controls** | **Boolean** |  |  [optional]
**loop** | **Boolean** |  |  [optional]
**muted** | **Boolean** |  |  [optional]
**playbackRates** | [**List&lt;BigDecimal&gt;**](BigDecimal.md) |  |  [optional]
