# HLS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**labels** | **List&lt;String&gt;** |  |  [optional]
**labelsBitrate** | **Map&lt;String, String&gt;** |  |  [optional]
**src** | **String** |  |  [optional]
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]

<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
APPLICATION_X_MPEGURL | &quot;application/x-mpegurl&quot;
