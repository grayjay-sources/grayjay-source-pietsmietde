# HeadlinesGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;Datum15&gt;**](Datum15.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
