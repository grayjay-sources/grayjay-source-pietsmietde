# IndigoVariation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | [**FileEnum**](#FileEnum) |  |  [optional]
**height** | **Integer** |  |  [optional]
**url** | **String** |  |  [optional]

<a name="FileEnum"></a>
## Enum: FileEnum
Name | Value
---- | -----
_98A4DBC8A467110AC6FC68DDFE81706158EF5B5C_JPG | &quot;98a4dbc8a467110ac6fc68ddfe81706158ef5b5c.jpg&quot;
_58F09A0BC9473E6CF72BCC00ECE09DDDA0955A37_JPG | &quot;58f09a0bc9473e6cf72bcc00ece09ddda0955a37.jpg&quot;
_525CE5D7D1EFA88885B2D2DC0A7B477C224AD845_JPG | &quot;525ce5d7d1efa88885b2d2dc0a7b477c224ad845.jpg&quot;
