# Item

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **Object** |  |  [optional]
**externalUrl** | **Object** |  |  [optional]
**externalUrlPlatform** | **Object** |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**publishDateSecondary** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**title** | **String** |  |  [optional]
**type** | **Integer** |  |  [optional]
**typeDefinition** | [**TypeDefinition**](TypeDefinition.md) |  |  [optional]
**video** | [**Video**](Video.md) |  |  [optional]
