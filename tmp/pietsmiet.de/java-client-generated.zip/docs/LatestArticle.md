# LatestArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | [**Author**](Author.md) |  |  [optional]
**categories** | [**List&lt;Category&gt;**](Category.md) |  |  [optional]
**commentsCount** | **Object** |  |  [optional]
**featured** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**intro** | [**IntroEnum**](#IntroEnum) |  |  [optional]
**preferences** | [**LatestArticlePreferences**](LatestArticlePreferences.md) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**slug** | [**SlugEnum**](#SlugEnum) |  |  [optional]
**text** | **Object** |  |  [optional]
**thumbnail** | [**LatestArticleThumbnail**](LatestArticleThumbnail.md) |  |  [optional]
**title** | [**TitleEnum**](#TitleEnum) |  |  [optional]
**url** | **String** |  |  [optional]
**urlSlug** | [**UrlSlugEnum**](#UrlSlugEnum) |  |  [optional]

<a name="IntroEnum"></a>
## Enum: IntroEnum
Name | Value
---- | -----
STIMMT_JETZT_BER_DIE_N_CHSTE_FOLGE_AB_ | &quot;Stimmt jetzt über die nächste Folge ab!&quot;
REICHT_EURE_VORSCHL_GE_EIN_ | &quot;Reicht eure Vorschläge ein!&quot;
UNSERE_TERMINE_AUF_DER_GAMESCOM | &quot;Unsere Termine auf der gamescom&quot;
MIT_DIESEN_TIPPS_MACHT_IHR_UNS_DAS_LEBEN_LEICHTER | &quot;Mit diesen Tipps macht ihr uns das Leben leichter&quot;
EIN_KLEINER_LEITFADEN_UM_EUCH_UND_UNS_DAS_LEBEN_ZU_ERLEICHTERN | &quot;Ein kleiner Leitfaden, um euch und uns das Leben zu erleichtern&quot;

<a name="SlugEnum"></a>
## Enum: SlugEnum
Name | Value
---- | -----
RETRO_BATTLE_UMFRAGE | &quot;retro-battle-umfrage&quot;
DIE_GOLDENE_EMMA_2024_EINREICHUNG_DEZEMBER_BIS_JULI | &quot;die-goldene-emma-2024-einreichung-dezember-bis-juli&quot;
GAMESCOM_2024_HIER_KONNT_IHR_DIE_JUNGS_TREFFEN | &quot;gamescom-2024-hier-konnt-ihr-die-jungs-treffen&quot;
SO_ERHOHT_IHR_DIE_CHANCE_DASS_WIR_EURE_SPIELSHOWS_SPIELEN | &quot;so-erhoht-ihr-die-chance-dass-wir-eure-spielshows-spielen&quot;
_50_FRAGEN_SO_SENDET_IHR_EURE_QUIZSHOW_RICHTIG_EIN | &quot;50-fragen-so-sendet-ihr-eure-quizshow-richtig-ein&quot;

<a name="TitleEnum"></a>
## Enum: TitleEnum
Name | Value
---- | -----
RETRO_BATTLE_UMFRAGE | &quot;Retro Battle: Umfrage&quot;
DIE_GOLDENE_EMMA_2024_EINREICHUNG_DEZEMBER_BIS_JULI | &quot;Die goldene Emma 2024: Einreichung Dezember bis Juli&quot;
GAMESCOM_2024_HIER_K_NNT_IHR_DIE_JUNGS_TREFFEN | &quot;gamescom 2024: Hier könnt ihr die Jungs treffen&quot;
SO_ERH_HT_IHR_DIE_CHANCE_DASS_WIR_EURE_SPIELSHOWS_SPIELEN_ | &quot;So erhöht ihr die Chance, dass wir eure Spielshows spielen!&quot;
_50_FRAGEN_SO_SENDET_IHR_EURE_QUIZSHOW_RICHTIG_EIN | &quot;50 Fragen: So sendet ihr eure Quizshow richtig ein&quot;

<a name="UrlSlugEnum"></a>
## Enum: UrlSlugEnum
Name | Value
---- | -----
_8586_RETRO_BATTLE_UMFRAGE | &quot;8586-retro-battle-umfrage&quot;
_8585_DIE_GOLDENE_EMMA_2024_EINREICHUNG_DEZEMBER_BIS_JULI | &quot;8585-die-goldene-emma-2024-einreichung-dezember-bis-juli&quot;
_8584_GAMESCOM_2024_HIER_KONNT_IHR_DIE_JUNGS_TREFFEN | &quot;8584-gamescom-2024-hier-konnt-ihr-die-jungs-treffen&quot;
_8582_SO_ERHOHT_IHR_DIE_CHANCE_DASS_WIR_EURE_SPIELSHOWS_SPIELEN | &quot;8582-so-erhoht-ihr-die-chance-dass-wir-eure-spielshows-spielen&quot;
_8581_50_FRAGEN_SO_SENDET_IHR_EURE_QUIZSHOW_RICHTIG_EIN | &quot;8581-50-fragen-so-sendet-ihr-eure-quizshow-richtig-ein&quot;
