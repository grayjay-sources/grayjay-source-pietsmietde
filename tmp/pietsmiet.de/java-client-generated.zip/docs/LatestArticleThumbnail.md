# LatestArticleThumbnail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collection** | [**CollectionEnum**](#CollectionEnum) |  |  [optional]
**id** | **Integer** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**variations** | [**List&lt;PurpleVariation&gt;**](PurpleVariation.md) |  |  [optional]

<a name="CollectionEnum"></a>
## Enum: CollectionEnum
Name | Value
---- | -----
THUMBNAIL | &quot;thumbnail&quot;
