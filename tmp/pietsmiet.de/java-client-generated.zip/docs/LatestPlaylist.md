# LatestPlaylist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channel** | [**Channel**](Channel.md) |  |  [optional]
**description** | **Object** |  |  [optional]
**firstVideo** | [**FirstVideo**](FirstVideo.md) |  |  [optional]
**followingsCount** | **Integer** |  |  [optional]
**id** | **Integer** |  |  [optional]
**metaTags** | **Object** |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**slug** | [**SlugEnum**](#SlugEnum) |  |  [optional]
**title** | [**TitleEnum**](#TitleEnum) |  |  [optional]
**type** | **Integer** |  |  [optional]
**urlSlug** | [**UrlSlugEnum**](#UrlSlugEnum) |  |  [optional]
**videosCount** | **Integer** |  |  [optional]

<a name="SlugEnum"></a>
## Enum: SlugEnum
Name | Value
---- | -----
RETRO_BATTLE | &quot;retro-battle&quot;
BETRAYAL_BEACH | &quot;betrayal-beach&quot;
BACK_TO_SCHOOL | &quot;back-to-school&quot;
ABC_QUIZ | &quot;abc-quiz&quot;
UPN_DOWN | &quot;upn-down&quot;

<a name="TitleEnum"></a>
## Enum: TitleEnum
Name | Value
---- | -----
RETRO_BATTLE | &quot;Retro Battle&quot;
BETRAYAL_BEACH | &quot;Betrayal Beach&quot;
BACK_TO_SCHOOL | &quot;Back to School&quot;
ABC_QUIZ | &quot;ABC Quiz&quot;
UP_N_DOWN | &quot;UP\&quot;N DOWN&quot;

<a name="UrlSlugEnum"></a>
## Enum: UrlSlugEnum
Name | Value
---- | -----
_155942_RETRO_BATTLE | &quot;155942-retro-battle&quot;
_155893_BETRAYAL_BEACH | &quot;155893-betrayal-beach&quot;
_155866_BACK_TO_SCHOOL | &quot;155866-back-to-school&quot;
_155762_ABC_QUIZ | &quot;155762-abc-quiz&quot;
_155689_UPN_DOWN | &quot;155689-upn-down&quot;
