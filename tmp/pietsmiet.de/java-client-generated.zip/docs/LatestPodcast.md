# LatestPodcast

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commentsCount** | **Object** |  |  [optional]
**description** | **Object** |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**metaTags** | **Object** |  |  [optional]
**mime** | [**MimeEnum**](#MimeEnum) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**size** | **Integer** |  |  [optional]
**slug** | [**SlugEnum**](#SlugEnum) |  |  [optional]
**sourceUrl** | **String** |  |  [optional]
**thumbnail** | [**LatestPodcastThumbnail**](LatestPodcastThumbnail.md) |  |  [optional]
**title** | [**TitleEnum**](#TitleEnum) |  |  [optional]
**urlSlug** | [**UrlSlugEnum**](#UrlSlugEnum) |  |  [optional]

<a name="MimeEnum"></a>
## Enum: MimeEnum
Name | Value
---- | -----
AUDIO_MPEG | &quot;audio/mpeg&quot;

<a name="SlugEnum"></a>
## Enum: SlugEnum
Name | Value
---- | -----
PIETCAST_447_SO_WAR_DIE_GAMESCOM | &quot;pietcast-447-so-war-die-gamescom&quot;

<a name="TitleEnum"></a>
## Enum: TitleEnum
Name | Value
---- | -----
PIETCAST_447_SO_WAR_DIE_GAMESCOM | &quot;PietCast #447 - So war die Gamescom&quot;

<a name="UrlSlugEnum"></a>
## Enum: UrlSlugEnum
Name | Value
---- | -----
_3336_PIETCAST_447_SO_WAR_DIE_GAMESCOM | &quot;3336-pietcast-447-so-war-die-gamescom&quot;
