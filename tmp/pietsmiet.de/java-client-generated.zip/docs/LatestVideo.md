# LatestVideo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channels** | [**List&lt;Channel&gt;**](Channel.md) |  |  [optional]
**commentsCount** | **Object** |  |  [optional]
**description** | **Object** |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | **AnyOfLatestVideoDurationPretty** |  |  [optional]
**featured** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**likesCount** | **Object** |  |  [optional]
**perspectives** | [**List&lt;LatestVideoPerspective&gt;**](LatestVideoPerspective.md) |  |  [optional]
**preferences** | [**LatestArticlePreferences**](LatestArticlePreferences.md) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**remote** | **Boolean** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**shortUrl** | **String** |  |  [optional]
**slug** | [**SlugEnum**](#SlugEnum) |  |  [optional]
**thumbnail** | [**LatestVideoThumbnail**](LatestVideoThumbnail.md) |  |  [optional]
**title** | [**TitleEnum**](#TitleEnum) |  |  [optional]
**url** | **String** |  |  [optional]
**urlSlug** | [**UrlSlugEnum**](#UrlSlugEnum) |  |  [optional]

<a name="SlugEnum"></a>
## Enum: SlugEnum
Name | Value
---- | -----
RENTNER_TESTEN_DIE_BLACK_OPS_6_BETA | &quot;rentner-testen-die-black-ops-6-beta&quot;
MONTY_MAULWURF_MVP_WORMS_CLAN_WARS | &quot;monty-maulwurf-mvp-worms-clan-wars&quot;
REACT_DAS_IST_BERLIN | &quot;react-das-ist-berlin&quot;
BESCHREIBE_ES_IN_WORTEN_JACKBOX_GAMES_BLATHER_ROUND | &quot;beschreibe-es-in-worten-jackbox-games-blather-round&quot;
MINECRAFT_MEETS_TERRARIA_PIETSMIET_PROBIERT_CORE_KEEPER_10 | &quot;minecraft-meets-terraria-pietsmiet-probiert-core-keeper-10&quot;

<a name="TitleEnum"></a>
## Enum: TitleEnum
Name | Value
---- | -----
RENTNER_TESTEN_DIE_BLACK_OPS_6_BETA | &quot;Rentner testen die Black Ops 6 Beta&quot;
MONTY_MAULWURF_MVP_WORMS_CLAN_WARS | &quot;Monty-Maulwurf MVP | Worms Clan Wars&quot;
REACT_DAS_IST_BERLIN_56 | &quot;React: Das ist Berlin #56&quot;
BESCHREIBE_ES_IN_WORTEN_JACKBOX_GAMES_BLATHER_ROUND | &quot;BESCHREIBE es in WORTEN! | Jackbox Games Blather \&quot;Round&quot;
MINECRAFT_MEETS_TERRARIA_PIETSMIET_PROBIERT_CORE_KEEPER_1_0 | &quot;Minecraft meets Terraria | PietSmiet probiert Core Keeper 1.0&quot;

<a name="UrlSlugEnum"></a>
## Enum: UrlSlugEnum
Name | Value
---- | -----
_79656_RENTNER_TESTEN_DIE_BLACK_OPS_6_BETA | &quot;79656-rentner-testen-die-black-ops-6-beta&quot;
_79538_MONTY_MAULWURF_MVP_WORMS_CLAN_WARS | &quot;79538-monty-maulwurf-mvp-worms-clan-wars&quot;
_79573_REACT_DAS_IST_BERLIN | &quot;79573-react-das-ist-berlin&quot;
_79569_BESCHREIBE_ES_IN_WORTEN_JACKBOX_GAMES_BLATHER_ROUND | &quot;79569-beschreibe-es-in-worten-jackbox-games-blather-round&quot;
_79651_MINECRAFT_MEETS_TERRARIA_PIETSMIET_PROBIERT_CORE_KEEPER_10 | &quot;79651-minecraft-meets-terraria-pietsmiet-probiert-core-keeper-10&quot;
