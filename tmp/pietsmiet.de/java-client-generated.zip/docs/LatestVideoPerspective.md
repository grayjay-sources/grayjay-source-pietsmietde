# LatestVideoPerspective

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**main** | **Boolean** |  |  [optional]
**title** | **Object** |  |  [optional]
**titlePluralized** | [**TitlePluralizedEnum**](#TitlePluralizedEnum) |  |  [optional]

<a name="TitlePluralizedEnum"></a>
## Enum: TitlePluralizedEnum
Name | Value
---- | -----
S | &quot;s&quot;
BRAMMENS | &quot;Brammens&quot;
CHRIS_ | &quot;Chris\\&#x27;&quot;
PETERS | &quot;Peters&quot;
SEPS | &quot;Seps&quot;
JULES | &quot;Jules&quot;
SVENS | &quot;Svens&quot;
HAUPTSICHTS | &quot;Hauptsichts&quot;
