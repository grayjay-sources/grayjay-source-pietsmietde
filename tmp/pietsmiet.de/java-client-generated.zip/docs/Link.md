# Link

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **Boolean** |  |  [optional]
**label** | **AnyOfLinkLabel** |  |  [optional]
**url** | **AnyOfLinkUrl** |  |  [optional]
