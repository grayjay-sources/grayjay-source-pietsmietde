# Links

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first** | **String** |  |  [optional]
**last** | **String** |  |  [optional]
**next** | **AnyOfLinksNext** |  |  [optional]
**prev** | **Object** |  |  [optional]
