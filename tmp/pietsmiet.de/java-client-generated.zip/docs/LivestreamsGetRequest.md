# LivestreamsGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;Datum14&gt;**](Datum14.md) |  |  [optional]
**links** | [**Links**](Links.md) |  |  [optional]
**meta** | [**Meta**](Meta.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
