# Meta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentPage** | **Integer** |  |  [optional]
**from** | **Integer** |  |  [optional]
**lastPage** | **Integer** |  |  [optional]
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**path** | **String** |  |  [optional]
**perPage** | **Integer** |  |  [optional]
**to** | **Integer** |  |  [optional]
**total** | **Integer** |  |  [optional]
