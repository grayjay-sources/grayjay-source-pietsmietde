# ModulesGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**Data1**](Data1.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
