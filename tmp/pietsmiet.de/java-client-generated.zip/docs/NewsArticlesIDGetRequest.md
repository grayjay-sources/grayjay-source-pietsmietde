# NewsArticlesIDGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**article** | [**Article**](Article.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
