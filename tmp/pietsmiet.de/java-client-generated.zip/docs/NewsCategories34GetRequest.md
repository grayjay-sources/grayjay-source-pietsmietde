# NewsCategories34GetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category** | [**Category**](Category.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
