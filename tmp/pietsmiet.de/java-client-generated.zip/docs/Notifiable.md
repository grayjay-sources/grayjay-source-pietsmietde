# Notifiable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blocked** | **Boolean** |  |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**description** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
**namePossessive** | **String** |  |  [optional]
**preferences** | [**Preferences1**](Preferences1.md) |  |  [optional]
**publicProfile** | **Boolean** |  |  [optional]
**reputation** | **Integer** |  |  [optional]
**reputationPretty** | **String** |  |  [optional]
**team** | **Boolean** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**urlSlug** | **String** |  |  [optional]
**username** | **String** |  |  [optional]
