# Notification

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**data** | [**Data**](Data.md) |  |  [optional]
**id** | [**UUID**](UUID.md) |  |  [optional]
**notifiable** | [**Notifiable**](Notifiable.md) |  |  [optional]
**notifiableId** | **Integer** |  |  [optional]
**notifiableType** | **String** |  |  [optional]
**read** | **Boolean** |  |  [optional]
**readAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**type** | **String** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
