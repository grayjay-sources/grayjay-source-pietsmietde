# Options

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**months** | **Integer** |  |  [optional]
