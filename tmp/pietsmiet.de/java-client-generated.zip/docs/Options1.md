# Options1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | **Integer** |  |  [optional]
**months** | **Integer** |  |  [optional]
