# Options2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**generic** | [**Generic**](Generic.md) |  |  [optional]
**tracks** | [**List&lt;Track&gt;**](Track.md) |  |  [optional]
**visual** | [**Visual**](Visual.md) |  |  [optional]
