# OtherCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cumulative** | **Boolean** |  |  [optional]
**description** | **Object** |  |  [optional]
**episodesCount** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**slug** | **String** |  |  [optional]
**spotifyUrl** | **Object** |  |  [optional]
**title** | **String** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
