# Perspective

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**main** | **Boolean** |  |  [optional]
**title** | **AnyOfPerspectiveTitle** |  |  [optional]
**titlePluralized** | **String** |  |  [optional]
