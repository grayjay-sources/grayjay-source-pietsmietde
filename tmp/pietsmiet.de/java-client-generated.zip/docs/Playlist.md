# Playlist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **Object** |  |  [optional]
**followingsCount** | **Integer** |  |  [optional]
**id** | **Integer** |  |  [optional]
**metaTags** | **Object** |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**slug** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**type** | **Integer** |  |  [optional]
**urlSlug** | **String** |  |  [optional]
**videosCount** | **Integer** |  |  [optional]
