# PodcastCategoriesGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;Datum3&gt;**](Datum3.md) |  |  [optional]
**links** | [**Links**](Links.md) |  |  [optional]
**meta** | [**Meta**](Meta.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
