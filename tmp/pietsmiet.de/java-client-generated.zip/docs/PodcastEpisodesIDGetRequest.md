# PodcastEpisodesIDGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**episode** | [**Episode**](Episode.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
