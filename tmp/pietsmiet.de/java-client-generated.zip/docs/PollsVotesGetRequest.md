# PollsVotesGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | **List&lt;Object&gt;** |  |  [optional]
**links** | [**Links**](Links.md) |  |  [optional]
**meta** | [**Meta**](Meta.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
