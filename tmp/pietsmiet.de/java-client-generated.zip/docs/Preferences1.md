# Preferences1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commentsOrderOwnFirst** | **Boolean** |  |  [optional]
**commentsOrderPopular** | **Boolean** |  |  [optional]
**country** | **String** |  |  [optional]
**enableDarkmode** | **Boolean** |  |  [optional]
**enableDarkmodeSchedule** | **Boolean** |  |  [optional]
**enableSpoilers** | **Boolean** |  |  [optional]
**publicProfile** | **Boolean** |  |  [optional]
**scrollTopRouteChange** | **Boolean** |  |  [optional]
**showInPresence** | **Boolean** |  |  [optional]
**showInSubscribedUsers** | **Boolean** |  |  [optional]
**subscribeNewsletter** | **Boolean** |  |  [optional]
**subscriptionEnableIdentification** | **Boolean** |  |  [optional]
**subscriptionKeepAds** | **Boolean** |  |  [optional]
**timezone** | **String** |  |  [optional]
**useGravatar** | **Boolean** |  |  [optional]
**videosAutocontinue** | **Boolean** |  |  [optional]
**videosAutoplay** | **Boolean** |  |  [optional]
**videosPlayerFloating** | **Boolean** |  |  [optional]
