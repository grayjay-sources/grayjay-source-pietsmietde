# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**braintreeId** | **String** |  |  [optional]
**braintreePlan** | **Object** |  |  [optional]
**details** | [**Details**](Details.md) |  |  [optional]
**enabled** | **Boolean** |  |  [optional]
**id** | **String** |  |  [optional]
**options** | [**Options**](Options.md) |  |  [optional]
**supportAddOn** | [**SupportAddOn**](SupportAddOn.md) |  |  [optional]
**type** | **String** |  |  [optional]
