# Properties

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**from** | [**From**](From.md) |  |  [optional]
**id** | **Integer** |  |  [optional]
**timestamp** | **Integer** |  |  [optional]
**to** | [**To**](To.md) |  |  [optional]
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]
**video** | **Integer** |  |  [optional]

<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
VIDEO | &quot;video&quot;
PODCASTEPISODE | &quot;podcastEpisode&quot;
NEWSARTICLE | &quot;newsArticle&quot;
VIDEOPLAYLIST | &quot;videoPlaylist&quot;
