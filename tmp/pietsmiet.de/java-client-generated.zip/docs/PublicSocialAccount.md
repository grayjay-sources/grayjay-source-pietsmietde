# PublicSocialAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**externalUrl** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
**service** | [**ServiceEnum**](#ServiceEnum) |  |  [optional]
**serviceDefinition** | [**ServiceDefinition**](ServiceDefinition.md) |  |  [optional]
**socialId** | **Object** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**username** | **String** |  |  [optional]

<a name="ServiceEnum"></a>
## Enum: ServiceEnum
Name | Value
---- | -----
TWITTER | &quot;twitter&quot;
TWITCH | &quot;twitch&quot;
INSTAGRAM | &quot;instagram&quot;
TIKTOK | &quot;tiktok&quot;
YOUTUBE | &quot;youtube&quot;
