# PurpleCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cumulative** | **Boolean** |  |  [optional]
**description** | **Object** |  |  [optional]
**episodesCount** | **Object** |  |  [optional]
**id** | **Integer** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**slug** | [**SlugEnum**](#SlugEnum) |  |  [optional]
**spotifyUrl** | **Object** |  |  [optional]
**title** | [**TitleEnum**](#TitleEnum) |  |  [optional]
**urlSlug** | [**UrlSlugEnum**](#UrlSlugEnum) |  |  [optional]

<a name="SlugEnum"></a>
## Enum: SlugEnum
Name | Value
---- | -----
PETERHEISSTPODCAST | &quot;peterheisstpodcast&quot;
PIETCAST | &quot;pietcast&quot;

<a name="TitleEnum"></a>
## Enum: TitleEnum
Name | Value
---- | -----
PETER_HEI_T_PODCAST | &quot;Peter heißt Podcast&quot;
PIETCAST | &quot;PietCast&quot;

<a name="UrlSlugEnum"></a>
## Enum: UrlSlugEnum
Name | Value
---- | -----
_36_PETERHEISSTPODCAST | &quot;36-peterheisstpodcast&quot;
_31_PIETCAST | &quot;31-pietcast&quot;
