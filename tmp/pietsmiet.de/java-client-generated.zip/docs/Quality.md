# Quality

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bitrate** | **Integer** |  |  [optional]
**framerate** | **Integer** |  |  [optional]
**label** | **String** |  |  [optional]
