# SchedulesGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;Datum18&gt;**](Datum18.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
