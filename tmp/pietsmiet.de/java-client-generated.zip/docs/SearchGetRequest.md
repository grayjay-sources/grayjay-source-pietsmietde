# SearchGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**counts** | [**Counts**](Counts.md) |  |  [optional]
**data** | [**List&lt;Datum7&gt;**](Datum7.md) |  |  [optional]
**links** | [**Links**](Links.md) |  |  [optional]
**meta** | [**Meta**](Meta.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
