# ServiceDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**color** | [**ColorEnum**](#ColorEnum) |  |  [optional]
**title** | [**TitleEnum**](#TitleEnum) |  |  [optional]

<a name="ColorEnum"></a>
## Enum: ColorEnum
Name | Value
---- | -----
BLUE | &quot;blue&quot;
PURPLE | &quot;purple&quot;
ORANGE | &quot;orange&quot;
PINK | &quot;pink&quot;
RED | &quot;red&quot;

<a name="TitleEnum"></a>
## Enum: TitleEnum
Name | Value
---- | -----
TWITTER | &quot;Twitter&quot;
TWITCH | &quot;Twitch&quot;
INSTAGRAM | &quot;Instagram&quot;
TIKTOK | &quot;TikTok&quot;
YOUTUBE | &quot;YouTube&quot;
