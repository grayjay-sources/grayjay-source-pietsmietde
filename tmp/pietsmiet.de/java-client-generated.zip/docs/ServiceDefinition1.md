# ServiceDefinition1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**color** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
