# SocialAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**externalUrl** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
**service** | **String** |  |  [optional]
**serviceDefinition** | [**ServiceDefinition1**](ServiceDefinition1.md) |  |  [optional]
**socialId** | **String** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**username** | **String** |  |  [optional]
