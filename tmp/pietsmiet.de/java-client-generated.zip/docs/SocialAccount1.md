# SocialAccount1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**externalUrl** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**name** | [**NameEnum**](#NameEnum) |  |  [optional]
**service** | [**ServiceEnum**](#ServiceEnum) |  |  [optional]
**serviceDefinition** | [**ServiceDefinition**](ServiceDefinition.md) |  |  [optional]
**socialId** | **String** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**username** | [**UsernameEnum**](#UsernameEnum) |  |  [optional]

<a name="NameEnum"></a>
## Enum: NameEnum
Name | Value
---- | -----
BLU | &quot;blu&quot;
USERNAMELP | &quot;userNameLP&quot;
USERNAME_ | &quot;userName_&quot;

<a name="ServiceEnum"></a>
## Enum: ServiceEnum
Name | Value
---- | -----
DISCORD | &quot;discord&quot;
TWITCH | &quot;twitch&quot;

<a name="UsernameEnum"></a>
## Enum: UsernameEnum
Name | Value
---- | -----
BLU_4340 | &quot;blu#4340&quot;
USERNAMELP | &quot;userNameLP&quot;
USERNAME__0 | &quot;userName_#0&quot;
