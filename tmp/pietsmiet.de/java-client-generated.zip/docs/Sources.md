# Sources

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dash** | [**Dash**](Dash.md) |  |  [optional]
**hls** | [**HLS**](HLS.md) |  |  [optional]
**mp4** | **Object** |  |  [optional]
