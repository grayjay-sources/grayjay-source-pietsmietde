# Status

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**colorBg** | **String** |  |  [optional]
**colorText** | **String** |  |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**isClosed** | **Boolean** |  |  [optional]
**name** | **String** |  |  [optional]
**reason** | **Object** |  |  [optional]
**title** | **String** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
