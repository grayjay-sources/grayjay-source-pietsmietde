# SubscriptionsProductsGetRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List&lt;Datum12&gt;**](Datum12.md) |  |  [optional]
**success** | **Boolean** |  |  [optional]
