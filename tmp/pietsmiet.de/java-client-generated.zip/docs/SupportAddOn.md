# SupportAddOn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**max** | **Integer** |  |  [optional]
**min** | **Integer** |  |  [optional]
**title** | **String** |  |  [optional]
**titleLong** | **String** |  |  [optional]
