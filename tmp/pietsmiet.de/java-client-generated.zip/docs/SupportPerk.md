# SupportPerk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  |  [optional]
**urls** | [**List&lt;URL&gt;**](URL.md) |  |  [optional]
