# TentacledVariation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **String** |  |  [optional]
**height** | **Integer** |  |  [optional]
**url** | **String** |  |  [optional]
