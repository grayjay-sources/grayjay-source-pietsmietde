# Thumbnail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collection** | [**CollectionEnum**](#CollectionEnum) |  |  [optional]
**id** | **Integer** |  |  [optional]
**remoteUrl** | **AnyOfThumbnailRemoteUrl** |  |  [optional]
**variations** | [**List&lt;Variation1&gt;**](Variation1.md) |  |  [optional]

<a name="CollectionEnum"></a>
## Enum: CollectionEnum
Name | Value
---- | -----
THUMBNAIL | &quot;thumbnail&quot;
