# Token

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientId** | **Integer** |  |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**expiresAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**id** | **String** |  |  [optional]
**ip** | **Object** |  |  [optional]
**lastSeen** | **Object** |  |  [optional]
**name** | **Object** |  |  [optional]
**revoked** | **Boolean** |  |  [optional]
**scopes** | **List&lt;Object&gt;** |  |  [optional]
**tfaVerifiedAt** | **Object** |  |  [optional]
**ua** | **Object** |  |  [optional]
**uaBrowser** | **Object** |  |  [optional]
**uaDevice** | **Object** |  |  [optional]
**uaOs** | **Object** |  |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**user** | [**User**](User.md) |  |  [optional]
**userId** | **Integer** |  |  [optional]
