# Track

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fullTitle** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**main** | **Boolean** |  |  [optional]
**pluralizedTitle** | **String** |  |  [optional]
**qualities** | [**List&lt;Quality&gt;**](Quality.md) |  |  [optional]
**sources** | [**Sources**](Sources.md) |  |  [optional]
**title** | **Object** |  |  [optional]
