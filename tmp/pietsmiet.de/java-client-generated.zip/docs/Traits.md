# Traits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**c** | **Integer** |  |  [optional]
**h** | **Integer** |  |  [optional]
**v** | **Integer** |  |  [optional]
