# TrendingVideo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channels** | [**List&lt;Channel&gt;**](Channel.md) |  |  [optional]
**commentsCount** | **Object** |  |  [optional]
**description** | **Object** |  |  [optional]
**duration** | **Integer** |  |  [optional]
**durationPretty** | [**DurationPrettyEnum**](#DurationPrettyEnum) |  |  [optional]
**featured** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]
**likesCount** | **Object** |  |  [optional]
**perspectives** | [**List&lt;TrendingVideoPerspective&gt;**](TrendingVideoPerspective.md) |  |  [optional]
**preferences** | [**LatestArticlePreferences**](LatestArticlePreferences.md) |  |  [optional]
**publishDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**remote** | **Boolean** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**shortUrl** | **String** |  |  [optional]
**slug** | [**SlugEnum**](#SlugEnum) |  |  [optional]
**thumbnail** | [**TrendingVideoThumbnail**](TrendingVideoThumbnail.md) |  |  [optional]
**title** | [**TitleEnum**](#TitleEnum) |  |  [optional]
**url** | [**UrlEnum**](#UrlEnum) |  |  [optional]
**urlSlug** | [**UrlSlugEnum**](#UrlSlugEnum) |  |  [optional]

<a name="DurationPrettyEnum"></a>
## Enum: DurationPrettyEnum
Name | Value
---- | -----
_32_17 | &quot;32:17&quot;
_49_22 | &quot;49:22&quot;
_47_23 | &quot;47:23&quot;
_38_32 | &quot;38:32&quot;
_23_34 | &quot;23:34&quot;

<a name="SlugEnum"></a>
## Enum: SlugEnum
Name | Value
---- | -----
DA_WURDE_JA_KEINER_RUNTERFALLEN_ODER_TTT | &quot;da-wurde-ja-keiner-runterfallen-oder-ttt&quot;
ICH_MUSS_HIER_RAUS_PERFECT_HEIST_2 | &quot;ich-muss-hier-raus-perfect-heist-2&quot;
TRACKMANIA_MINECRAFT | &quot;trackmania-minecraft&quot;
VALVES_HYPE_SPIEL_DEADLOCK | &quot;valves-hype-spiel-deadlock&quot;
GUESS_THE_GAME_3GG3_SPECIAL | &quot;guess-the-game-3gg3-special&quot;

<a name="TitleEnum"></a>
## Enum: TitleEnum
Name | Value
---- | -----
DA_W_RDE_JA_KEINER_RUNTERFALLEN_ODER_TTT | &quot;Da würde ja keiner RUNTERFALLEN! oder? | TTT&quot;
ICH_MUSS_RAUS_PERFECT_HEIST_2 | &quot;ICH MUSS RAUS! | Perfect Heist 2&quot;
BESSER_WIRDS_NICHT_MEHR_TRACKMANIA_X_MINECRAFT | &quot;BESSER WIRDS NICHT MEHR! | Trackmania x Minecraft&quot;
VALVES_HYPE_SPIEL_DEADLOCK | &quot;VALVES HYPE SPIEL! | Deadlock&quot;
GUESS_THE_GAME_3GG3_SPECIAL_ | &quot;Guess The Game 3gg3 SPECIAL!&quot;

<a name="UrlEnum"></a>
## Enum: UrlEnum
Name | Value
---- | -----
_79620_DA_WURDE_JA_KEINER_RUNTERFALLEN_ODER_TTT | &quot;/videos/79620-da-wurde-ja-keiner-runterfallen-oder-ttt&quot;
_79622_ICH_MUSS_HIER_RAUS_PERFECT_HEIST_2 | &quot;/videos/79622-ich-muss-hier-raus-perfect-heist-2&quot;
_79618_TRACKMANIA_MINECRAFT | &quot;/videos/79618-trackmania-minecraft&quot;
_79632_VALVES_HYPE_SPIEL_DEADLOCK | &quot;/videos/79632-valves-hype-spiel-deadlock&quot;
_79636_GUESS_THE_GAME_3GG3_SPECIAL | &quot;/videos/79636-guess-the-game-3gg3-special&quot;

<a name="UrlSlugEnum"></a>
## Enum: UrlSlugEnum
Name | Value
---- | -----
_79620_DA_WURDE_JA_KEINER_RUNTERFALLEN_ODER_TTT | &quot;79620-da-wurde-ja-keiner-runterfallen-oder-ttt&quot;
_79622_ICH_MUSS_HIER_RAUS_PERFECT_HEIST_2 | &quot;79622-ich-muss-hier-raus-perfect-heist-2&quot;
_79618_TRACKMANIA_MINECRAFT | &quot;79618-trackmania-minecraft&quot;
_79632_VALVES_HYPE_SPIEL_DEADLOCK | &quot;79632-valves-hype-spiel-deadlock&quot;
_79636_GUESS_THE_GAME_3GG3_SPECIAL | &quot;79636-guess-the-game-3gg3-special&quot;
