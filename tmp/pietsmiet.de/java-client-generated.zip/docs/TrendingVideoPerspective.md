# TrendingVideoPerspective

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**main** | **Boolean** |  |  [optional]
**title** | **AnyOfTrendingVideoPerspectiveTitle** |  |  [optional]
**titlePluralized** | **String** |  |  [optional]
