# TrendingVideoThumbnail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**collection** | [**CollectionEnum**](#CollectionEnum) |  |  [optional]
**id** | **Integer** |  |  [optional]
**remoteUrl** | **Object** |  |  [optional]
**variations** | [**List&lt;IndecentVariation&gt;**](IndecentVariation.md) |  |  [optional]

<a name="CollectionEnum"></a>
## Enum: CollectionEnum
Name | Value
---- | -----
THUMBNAIL | &quot;thumbnail&quot;
