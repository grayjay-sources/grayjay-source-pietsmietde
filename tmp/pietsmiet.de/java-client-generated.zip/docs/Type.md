# Type

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channels** | [**Channels**](Channels.md) |  |  [optional]
**description** | [**DescriptionEnum**](#DescriptionEnum) |  |  [optional]
**key** | [**KeyEnum**](#KeyEnum) |  |  [optional]

<a name="DescriptionEnum"></a>
## Enum: DescriptionEnum
Name | Value
---- | -----
T_GLICHE_VIDEOZUSAMMENFASSUNG | &quot;Tägliche Videozusammenfassung&quot;
W_CHENTLICHE_VIDEOZUSAMMENFASSUNG | &quot;Wöchentliche Videozusammenfassung&quot;
ANTWORT_AUF_KOMMENTAR | &quot;Antwort auf Kommentar&quot;
KOMMENTAR_IST_BELIEBT | &quot;Kommentar ist beliebt&quot;
ERW_HNUNG_IN_EINEM_KOMMENTAR | &quot;Erwähnung in einem Kommentar&quot;
NEUE_ARTIKEL | &quot;Neue Artikel&quot;

<a name="KeyEnum"></a>
## Enum: KeyEnum
Name | Value
---- | -----
VIDEO_SUMMARY_DAILY | &quot;VIDEO_SUMMARY_DAILY&quot;
VIDEO_SUMMARY_WEEKLY | &quot;VIDEO_SUMMARY_WEEKLY&quot;
COMMENT_REPLIED | &quot;COMMENT_REPLIED&quot;
COMMENT_IS_POPULAR | &quot;COMMENT_IS_POPULAR&quot;
COMMENT_MENTIONED | &quot;COMMENT_MENTIONED&quot;
NEW_NEWS_ARTICLES | &quot;NEW_NEWS_ARTICLES&quot;
