# Type1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**channels** | [**Channels**](Channels.md) |  |  [optional]
**description** | **String** |  |  [optional]
**key** | **String** |  |  [optional]
