# TypeDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | [**TitleEnum**](#TitleEnum) |  |  [optional]

<a name="TitleEnum"></a>
## Enum: TitleEnum
Name | Value
---- | -----
VIDEO | &quot;Video&quot;
