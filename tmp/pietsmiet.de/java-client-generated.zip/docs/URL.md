# URL

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **String** |  |  [optional]
**replace** | **String** |  |  [optional]
**search** | **String** |  |  [optional]
