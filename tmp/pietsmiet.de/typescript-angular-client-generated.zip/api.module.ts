import { NgModule, ModuleWithProviders, SkipSelf, Optional } from '@angular/core';
import { Configuration } from './configuration';
import { HttpClient } from '@angular/common/http';


import { CommunityService } from './api/community.service';
import { ConfigService } from './api/config.service';
import { HeadlinesService } from './api/headlines.service';
import { LivestreamsService } from './api/livestreams.service';
import { ModulesService } from './api/modules.service';
import { NewsService } from './api/news.service';
import { PodcastService } from './api/podcast.service';
import { PollsService } from './api/polls.service';
import { PromotionsService } from './api/promotions.service';
import { SchedulesService } from './api/schedules.service';
import { SearchService } from './api/search.service';
import { SubscriptionsService } from './api/subscriptions.service';
import { TagsService } from './api/tags.service';
import { UsersService } from './api/users.service';
import { UtilityService } from './api/utility.service';
import { VideosService } from './api/videos.service';

@NgModule({
  imports:      [],
  declarations: [],
  exports:      [],
  providers: [
    CommunityService,
    ConfigService,
    HeadlinesService,
    LivestreamsService,
    ModulesService,
    NewsService,
    PodcastService,
    PollsService,
    PromotionsService,
    SchedulesService,
    SearchService,
    SubscriptionsService,
    TagsService,
    UsersService,
    UtilityService,
    VideosService ]
})
export class ApiModule {
    public static forRoot(configurationFactory: () => Configuration): ModuleWithProviders<ApiModule> {
        return {
            ngModule: ApiModule,
            providers: [ { provide: Configuration, useFactory: configurationFactory } ]
        };
    }

    constructor( @Optional() @SkipSelf() parentModule: ApiModule,
                 @Optional() http: HttpClient) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
            'See also https://github.com/angular/angular/issues/20575');
        }
    }
}
